<!-- Topbar -->
<div class="top-bar container">
	<div class="row">
		<div class="col-md-6">
			<ul class="tb-left">
				<li class="tbl-date">   <?php  if (isset($_SESSION['username'])) : ?>
    	<p>Welcome <strong><?php echo $_SESSION['username']; ?></strong></p>
		<li><p> <a href="index.php?logout='1'" style="color: red;">logout</a> </p></li>

    <?php endif ?>
</li>
			</ul>
		</div>
		<div class="col-md-6">
			<ul class="tb-right">
				<li class="tbr-social">
					<span>
					<a href="http://www.facebook.com" class="fa fa-facebook"></a>
					<a href="http://www.twitter.com" class="fa fa-twitter"></a>
					<a href="http://www.google.com" class="fa fa-google-plus"></a>
					<a href="htttp://www.printtest.com" class="fa fa-pinterest"></a>
					<a href="http://www.youtube.com" class="fa fa-youtube"></a>
					
					</span>
				</li>
				<li class="tbr-login">
				<!--	<a href="./login.php">Login</a> -->
				</li>
			</ul>
		</div>
	</div>
</div>