<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->
<head>

	<!-- Meta -->
	<meta charset="utf-8">
	<meta name="keywords" content="HTML5 Template" />
	<meta name="description" content="">
	<meta name="author" content="">

    <title>Gazeta - Responsive Magazine Blog Template</title>

	<!-- Mobile Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Favicons -->
	<link rel="shortcut icon" href="img/favicon.ico">

	<!-- Google Fonts & Fontawesome -->
	<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href='http://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Josefin+Sans:400,100,300,300italic,100italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>

	<!-- CSS -->
	<link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="js/vendor/slick/slick.css">
	<link rel="stylesheet" href="css/style.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

	<!-- JS - MEDIAQUERIES -->
	<script src="js/css3-mediaqueries.js"></script>
	
</head>
<body>

<div class="container wrapper">

	<!-- Header -->
	<header>
		<div class="col-md-12">
			<div class="row">

				<!-- Navigation -->
				<div class="col-md-12">
					<div class="menu-trigger"><i class="fa fa-align-justify"></i> Menu</div>
					<nav>
						<ul>
							<li class="active">
								<a href="#" class="sub-nav">Pages</a>
								<ul class="mega-menu">
									<li class="sub-menu">
										<ul>
											<li><a href="./index.php">Index 1</a></li>
											<li><a href="./3.php">Category</a></li>
											<li><a href="./about.php">About</a></li>
										</ul>
									</li>
									<li class="sub-menu">
										<ul>
											<li><a href="./archives.php">Archives</a></li>
											<li><a href="./contributor.php">Contributor</a></li>
										</ul>
									</li>
									<li class="sub-menu">
										<ul>
											<li><a href="./galleryindex.php">Gallery</a></li>
											<li><a href="./gallerydetail.php">Gallery Details</a></li>
											<li><a href="./login.php">Login</a></li>
										</ul>
									</li>
									<li class="sub-menu">
										<ul>
											<li><a href="./search.php">Search Results</a></li>
											<li><a href="./contact.php">Contact</a></li>
											<li><a href="./index.php">Single Post</a></li>

										</ul>
									</li>
								</ul>
							</li>
							<li><a href="#">Sport</a></li>
							<li><a href="#">Live News</a></li>
							<li><a href="#">Entertainment</a></li>
							<li><a href="#">Culture</a></li>
							<li><a href="#">Travelling</a></li>
							<li><a href="#">More</a></li>

						</ul>
					</nav>

					<!-- Search -->
					<div class="search">
						<form>
							<input type="search" placeholder="Type to search and hit enter">
						</form>
					</div>
					<span class="search-trigger"><i class="fa fa-search"></i></span>
				</div>
			</div>
		</div>
	</header>

	<div class="header">
		<div class="col-md-12">
			<div class="col-md-12">
				<!-- Logo -->
				<div class="col-md-4 logo">
					<h1><a href="./index.php">Epress</a></h1>
				</div>

				<!-- News Ticker -->
				<div class="col-md-8">
					<div class="news-ticker">
						<div id="news-ticker">
							<div class="item">
								<span>Entertainment</span>
								<h4><a href="./index.php">Movie : Mother - Real Beauty Comes from the Inside of a Woman</a></h4>
								<p>Posted on : November 4, 2014</p>
							</div>
							<div class="item">
								<span>Sport</span>
								<h4><a href="./index.php">Temper Cum Soluta Nobis Eleifend Option Congue Nihil</a></h4>
								<p>Posted on : November 2, 2014</p>
							</div>
							<div class="item">
								<span>Business</span>
								<h4><a href="./index.php">Duis autem vel irure dolor in hendrerit in vulputate</a></h4> 
								<p>Posted on : November 1, 2014</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>


<div class="clearfix space30"></div>

<!-- Javascript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/vendor/slick/slick.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/main.js"></script>

</body>
</html>
