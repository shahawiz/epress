
		<!-- Sidebar -->
		<aside class="col-md-4">
		
			<!-- Popular News -->
			<div class="side-widget p-news">
				<h5><span>Popular news</span></h5>
				<div class="sw-inner">
					<ul>
						<li>
							<img src="images/aside/1.jpg" alt=""/>
							<div class="pn-info">
								<span>Politic</span>
								<h4><a href="./single_post.html">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></h4>
							</div>
						</li>
						<li>
							<img src="images/aside/2.jpg" alt=""/>
							<div class="pn-info">
								<span>Politic</span>
								<h4><a href="./single_post.html">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></h4>
							</div>
						</li>
						<li>
							<img src="images/aside/3.jpg" alt=""/>
							<div class="pn-info">
								<span>Business</span>
								<h4><a href="./single_post.html">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></h4>
							</div>
						</li>
						<li>
							<img src="images/aside/4.jpg" alt=""/>
							<div class="pn-info">
								<span>Technology</span>
								<h4><a href="./single_post.html">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></h4>
							</div>
						</li>
						<li>
							<img src="images/aside/5.jpg" alt=""/>
							<div class="pn-info">
								<span>Uncategorized</span>
								<h4><a href="./single_post.html">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></h4>
							</div>
						</li>
					</ul>
				</div>
			</div>
			
			<!-- Banner -->
			<div class="side-widget sw-banner">
				<a href="#"><img src="images/banner/2.jpg" class="img-responsive" alt=""/></a>
			</div>

			<!-- Contributors  -->
			<div class="side-widget sw-contributors">
				<h5><span>Contributors</span></h5>
				<div class="sw-inner">
					<ul>
						<li><a href="./contributor.html"><img src="images/aside/1/1.jpg" class="img-responsive" alt=""/></a></li>
						<li><a href="./contributor.html"><img src="images/aside/1/2.jpg" class="img-responsive" alt=""/></a></li>
						<li><a href="./contributor.html"><img src="images/aside/1/3.jpg" class="img-responsive" alt=""/></a></li>
						<li><a href="./contributor.html"><img src="images/aside/1/4.jpg" class="img-responsive" alt=""/></a></li>
						<li><a href="./contributor.html"><img src="images/aside/1/5.jpg" class="img-responsive" alt=""/></a></li>
						<li><a href="./contributor.html"><img src="images/aside/1/6.jpg" class="img-responsive" alt=""/></a></li>
						<li><a href="./contributor.html"><img src="images/aside/1/7.jpg" class="img-responsive" alt=""/></a></li>
						<li><a href="./contributor.html"><img src="images/aside/1/8.jpg" class="img-responsive" alt=""/></a></li>
					</ul>
				</div>
			</div>
			
			<!-- Newsletter  -->
			<div class="side-widget sw-subscribe">
				<h5><span>Subscribe</span></h5>
				<div class="sw-inner">
					<div class="sws-inner">
						<img src="images/aside/8.jpg" alt=""/>
						<p>Make sure you don't miss interesting happenings by joining our newsletter program.<br>We don't do spam.</p>
					</div>
					<div id="newsletter">
						<form class="newsletter">
							<input type="email" placeholder="Enter Your Email Address">
						</form>
					</div>
				</div>
			</div>
		</aside>