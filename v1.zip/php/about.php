<!DOCTYPE html>
<head>
    <title>BonPom News</title>
</head>
<body>
<!-- Topbar -->
<?php
include("topbar.php");
?>
<div class="container wrapper">

<!-- header -->
<?php
 include("header.php");
?>

	<!-- Team Content -->
	<div class="main-content container">
		<div class="col-md-8 blog-single">
			<div class="bs-meta">
				<span class="bs-cat">About</span>
			</div>
			<div class="space30"></div>
			<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.</p>
			
			<!-- Team  -->
			<div class="team-content">
				<h3>The People Behind Success of Gazeta</h3>
				<ul>
					<li>
						<img src="images/team/1.png" alt=""/>
						<div class="tc-inner">
							<h4><a href="#">Jonathan Doe</a></h4>
							<span>Ceo of Gazeta</span>
							<p>Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum</p>
						</div>
					</li>
					
					<li>
						<img src="images/team/2.png" alt=""/>
						<div class="tc-inner">
							<h4><a href="#">John Smith</a></h4>
							<span>Executive Editor</span>
							<p>Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum</p>
						</div>
					</li>
					
					<li>
						<img src="images/team/3.png" alt=""/>
						<div class="tc-inner">
							<h4><a href="#">Robb Wallet</a></h4>
							<span>Publisher</span>
							<p>Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum</p>
						</div>
					</li>
					
					<li>
						<img src="images/team/4.png" alt=""/>
						<div class="tc-inner">
							<h4><a href="#">Owen Smith</a></h4>
							<span>Internet Marketer</span>
							<p>Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum</p>
						</div>
					</li>
					
					<li>
						<img src="images/team/5.png" alt=""/>
						<div class="tc-inner">
							<h4><a href="#">John Doe</a></h4>
							<span>Professional Writer</span>
							<p>Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum</p>
						</div>
					</li>
					
					<li>
						<img src="images/team/6.png" alt=""/>
						<div class="tc-inner">
							<h4><a href="#">Ibish Zverrxha</a></h4>
							<span>Professional Writer</span>
							<p>Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum</p>
						</div>
					</li>
					
					<li>
						<img src="images/team/7.png" alt=""/>
						<div class="tc-inner">
							<h4><a href="#">Habib Smithaj</a></h4>
							<span>Publisher</span>
							<p>Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum</p>
						</div>
					</li>
				</ul>
			</div>
		</div>
<!-- side bar-->
	<?php
 	include("side.php");
			?>
	</div>
	<div class="container wrapper">
		<!-- foter -->
		<?php
 		include("foter.php");
			?>
</div>
<div class="clearfix space30"></div>
</body>
</html>
