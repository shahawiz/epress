<!DOCTYPE html>
<head>
    <title>BonPom News</title>
	<script src="js/css3-mediaqueries.js"></script>
</head>
<body>
<!-- Topbar -->
<?php
include("topbar.php");
?>
<div class="container wrapper">

	<!-- Header -->
<!-- Topbar -->
<?php
include("header.php");
?>
	<!-- Contributor Content -->
	<div class="main-content container">
		<div class="col-md-8 blog-single">
			<div class="bs-meta">
				<span class="bs-cat">Contributor</span>
			</div>
			<div class="contributor-info">
				<img src="images/xtra/2.png" alt=""/>
				<h6>John Smith</h6>
				<div class="sep1"></div>
				<div class="space10"></div>
				<p>Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.</p>
				<div class="space30"></div>
				<div class="sep1"></div>
				<div class="space20"></div>
				<em class="share-count">Connect with John Smith</em>
				<span class="bsa-social">
				<a href="#"><i class="fa fa-facebook"></i></a>
				<a href="#"><i class="fa fa-twitter"></i></a>
				<a href="#"><i class="fa fa-pinterest"></i></a>
				<a href="#"><i class="fa fa-google-plus"></i></a>
				<a href="#"><i class="fa fa-linkedin"></i></a>
				<a href="#"><i class="fa fa-youtube-play"></i></a>
				</span>
			</div>
			
			<div class="related-posts related-posts-cat">
				<h5>John Smith Posts <span>(10) <i class="fa fa-angle-down"></i></span></h5>
				<ul>
					<li>
						<div class="col-md-3">
							<div class="rp-date">
								<span>November</span>
								04
								<span><em>/</em> 2014</span>
							</div>
						</div>
						<div class="col-md-9">
							<img src="images/blog/1/1.jpg" class="img-responsive" alt=""/>
							<div class="rp-inner">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
								<a href="#" class="rp-more">Read more  <em>&#8594;</em></a>
							</div>
						</div>
					</li>
					
					<li>
						<div class="col-md-3">
							<div class="rp-date">
								<span>October</span>
								29
								<span><em>/</em> 2014</span>
							</div>
						</div>
						<div class="col-md-9">
							<img src="images/blog/1/2.jpg" class="img-responsive" alt=""/>
							<div class="rp-inner">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
								<a href="#" class="rp-more">Read more  <em>&#8594;</em></a>
							</div>
						</div>
					</li>
					
					<li>
						<div class="col-md-3">
							<div class="rp-date">
								<span>October</span>
								23
								<span><em>/</em> 2014</span>
							</div>
						</div>
						<div class="col-md-9">
							<img src="images/blog/1/3.jpg" class="img-responsive" alt=""/>
							<div class="rp-inner">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
								<a href="#" class="rp-more">Read more  <em>&#8594;</em></a>
							</div>
						</div>
					</li>
					
					<li>
						<div class="col-md-3">
							<div class="rp-date">
								<span>October</span>
								18
								<span><em>/</em> 2014</span>
							</div>
						</div>
						<div class="col-md-9">
							<img src="images/blog/1/4.jpg" class="img-responsive" alt=""/>
							<div class="rp-inner">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
								<a href="#" class="rp-more">Read more  <em>&#8594;</em></a>
							</div>
						</div>
					</li>
					
					<li>
						<div class="col-md-3">
							<div class="rp-date">
								<span>October</span>
								07
								<span><em>/</em> 2014</span>
							</div>
						</div>
						<div class="col-md-9">
							<img src="images/blog/1/5.jpg" class="img-responsive" alt=""/>
							<div class="rp-inner">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
								<a href="#" class="rp-more">Read more  <em>&#8594;</em></a>
							</div>
						</div>
					</li>
					
					<li>
						<div class="col-md-3">
							<div class="rp-date">
								<span>October</span>
								02
								<span><em>/</em> 2014</span>
							</div>
						</div>
						<div class="col-md-9">
							<img src="images/blog/1/6.jpg" class="img-responsive" alt=""/>
							<div class="rp-inner">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
								<a href="#" class="rp-more">Read more  <em>&#8594;</em></a>
							</div>
						</div>
					</li>
					
					<li>
						<div class="col-md-3">
							<div class="rp-date">
								<span>September</span>
								30
								<span><em>/</em> 2014</span>
							</div>
						</div>
						<div class="col-md-9">
							<img src="images/blog/1/7.jpg" class="img-responsive" alt=""/>
							<div class="rp-inner">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
								<a href="#" class="rp-more">Read more  <em>&#8594;</em></a>
							</div>
						</div>
					</li>
					
					<li>
						<div class="col-md-3">
							<div class="rp-date">
								<span>September</span>
								25
								<span><em>/</em> 2014</span>
							</div>
						</div>
						<div class="col-md-9">
							<img src="images/blog/1/8.jpg" class="img-responsive" alt=""/>
							<div class="rp-inner">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
								<a href="#" class="rp-more">Read more  <em>&#8594;</em></a>
							</div>
						</div>
					</li>
					
					<li>
						<div class="col-md-3">
							<div class="rp-date">
								<span>September</span>
								12
								<span><em>/</em> 2014</span>
							</div>
						</div>
						<div class="col-md-9">
							<img src="images/blog/1/9.jpg" class="img-responsive" alt=""/>
							<div class="rp-inner">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
								<a href="#" class="rp-more">Read more  <em>&#8594;</em></a>
							</div>
						</div>
					</li>
					
					<li>
						<div class="col-md-3">
							<div class="rp-date">
								<span>September</span>
								06
								<span><em>/</em> 2014</span>
							</div>
						</div>
						<div class="col-md-9">
							<img src="images/blog/1/10.jpg" class="img-responsive" alt=""/>
							<div class="rp-inner">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
								<a href="#" class="rp-more">Read more  <em>&#8594;</em></a>
							</div>
						</div>
					</li>
				</ul>
			</div>
			
			<!-- Page Nav -->
			<div class="page-nav">
				<span>Page</span>
				<ul>
					<li class="active"><a href="#">1</a></li>
					<li><a href="#">2</a></li>
					<li><a href="#">3</a></li>
					<li><a href="#">4</a></li>
					<li><a href="#">...</a></li>
					<li><a href="#">11</a></li>
					<li><a href="#">12</a></li>
					<li><a href="#"><i class="fa fa-angle-double-right"></i></a></li>
				</ul>
			</div>
		</div>

		<!-- Sidebar -->

<?php
include("side.php");
?>
	</div>


	


	
	<!-- Footer -->

<?php
include("foter.php");
?>
</div>

</div>

<div class="clearfix space30"></div>

<!-- Javascript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/vendor/slick/slick.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/main.js"></script>

</body>
</html>
