<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->
<head>



    <title>Bon</title>


	<script src="js/css3-mediaqueries.js"></script>
	
</head>
<body>

<!-- Topbar -->
<?php
include("topbar.php");
?>



<div class="container wrapper">

	<!-- Header -->
	<?php
 	include("header.php");
		?>

	<div class="main-content container">

		<!-- Contact -->
		<div class="col-md-8 blog-single">
			<div class="bs-meta">
				<span class="bs-cat">Contact Us</span>
			</div>
			<div class="space30"></div>
			
			<!-- Google Map -->
			<div class="map">
				<div class="gmap">
					<div id="map"></div>
				</div>
			</div>
			<h3>Duis Autem Veleum Iriure Dolor in Hendrerit</h3>
			
			<!-- Contact Info -->
			<div class="c-info">
				<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat</p>
				<div class="space30"></div>
				<div class="row">
					<div class="col-md-6">
						<h6>Our Office Address I :</h6>
						<p><span>Location</span> <em>Kaliurang St. No 104,<br>Sinduharjo, Ngaglik,<br>Sleman.</em></p>
						<p><span>Telephone</span> <em>(0274) 9982732</em></p>
						<p><span>Email</span> <em>Staff@localhost.net</em></p>
						<p><span>Open Hour</span> <em>Monday - Friday </em></p>
					</div>
					<div class="col-md-6">
						<h6>Our Office Address II :</h6>
						<p><span>Location</span> <em>Gejayan St. No 11</em></p>
						<p><span>Telephone</span> <em>(0274) 9982732</em></p>
						<p><span>Email</span> <em>Staff@localhost.net</em></p>
						<p><span>Open Hour</span> <em>Monday - Friday <br>08:00 AM until 16:00 PM</em></p>
					</div>
				</div>
			</div>
			
			<div id="tabwrap" class="c-tabs">
				<!-- Contact Form --> 
				<ul id="tabs">
					<li class="current"><a href="#contact">Send Message</a></li>
				</ul>
				
				<div id="content">
					<div id="contact" class="current">
						<form class="c-form" id="contactForm" action="php/contact.php" method="post">
							<p>Your email address will not be published. Required fields are marked <span>*</span></p>
							<label>Name <span>*</span></label>
							<input type="text" name="senderName" id="senderName" Required>
							<label>Email <span>*</span></label>
							<input type="email" name="senderEmail" id="senderEmail" Required>
							<label>Subject <span>*</span></label>
							<input type="text" name="subject" id="subject" Required>
							<label>Message</label>
							<textarea name="message" id="message"></textarea>
							<button type="submit">Send Message</button>
						</form>
						<div id="successMessage" class="successmessage">
							<p><span class="success-ico"></span> Thanks for sending your message! We'll get back to you shortly.</p>
						</div>
						<div id="failureMessage" class="errormessage">
							<p><span class="error-ico"></span> There was a problem sending your message. Please try again.</p>
						</div>
						<div id="incompleteMessage" class="statusMessage">
							<p>Please complete all the fields in the form before sending.</p>
						</div>
					</div>
				</div>
			</div>
		</div>
		
		<!-- Sidebar -->
		<?php
 	include("side.php");
		?>
	</div>
	<!-- Footer - Fixed -->
	<?php
 	include("foter.php");
		?>
</div>
</div>
<div class="clearfix space30"></div>
<!-- Javascript -->
<!-- Javascript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/vendor/slick/slick.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/main.js"></script>
<script src="http://maps.google.com/maps/api/js?sensor=true"></script> 
<script src="js/vendor/gmap/gmaps.js"></script> 
<script src="js/vendor/gmap/plugin.js"></script>
<script src="js/contact.js"></script>
</body>
</html>
