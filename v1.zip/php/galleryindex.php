<!DOCTYPE html>
<head>
    <title>Gazeta - Responsive Magazine Blog Template</title>
	<script src="js/css3-mediaqueries.js"></script>
</head>
<body>
<!-- Topbar -->
<?php
 	include("topbar.php");
		?>
<div class="container wrapper">
	<!-- Header -->
	<?php
 	include("header.php");
		?>
	<!-- Gallery Posts -->
	<div class="main-content container">
		<div class="col-md-8 blog-single">
			<div class="bs-meta">
				<span class="bs-cat">Gallery Page</span>
			</div>
			<ul class="i-gallery">
				<li>
					<div class="ig-main">
						<div class="ig-wrap">
							<a href="./gallery_detail.html">
								<img src="images/gallery/1.jpg" class="img-responsive" alt=""/>
								<h4>Eodem modo typi, qui nunc nobis videntur parum clari</h4>
							</a>
						</div>
					</div>
				</li>
				<li>
					<div class="ig-main">
						<div class="ig-wrap">
							<a href="./gallery_detail.html">
								<img src="images/gallery/2.jpg" class="img-responsive" alt=""/>
								<h4>Eodem modo typi, qui nunc nobis videntur parum clari</h4>
							</a>
						</div>
					</div>
				</li>
				<li>
					<div class="ig-main">
						<div class="ig-wrap">
							<a href="./gallery_detail.html">
								<img src="images/gallery/3.jpg" class="img-responsive" alt=""/>
								<h4>Eodem modo typi, qui nunc nobis videntur parum clari</h4>
							</a>
						</div>
					</div>
				</li>
				<li>
					<div class="ig-main">
						<div class="ig-wrap">
							<a href="./gallery_detail.html">
								<img src="images/gallery/4.jpg" class="img-responsive" alt=""/>
								<h4>Eodem modo typi, qui nunc nobis videntur parum clari</h4>
							</a>
						</div>
					</div>
				</li>
				<li>
					<div class="ig-main">
						<div class="ig-wrap">
							<a href="./gallery_detail.html">
								<img src="images/gallery/5.jpg" class="img-responsive" alt=""/>
								<h4>Eodem modo typi, qui nunc nobis videntur parum clari</h4>
							</a>
						</div>
					</div>
				</li>
				<li>
					<div class="ig-main">
						<div class="ig-wrap">
							<a href="./gallery_detail.html">
								<img src="images/gallery/6.jpg" class="img-responsive" alt=""/>
								<h4>Eodem modo typi, qui nunc nobis videntur parum clari</h4>
							</a>
						</div>
					</div>
				</li>
				<li>
					<div class="ig-main">
						<div class="ig-wrap">
							<a href="./gallery_detail.html">
								<img src="images/gallery/7.jpg" class="img-responsive" alt=""/>
								<h4>Eodem modo typi, qui nunc nobis videntur parum clari</h4>
							</a>
						</div>
					</div>
				</li>
				<li>
					<div class="ig-main">
						<div class="ig-wrap">
							<a href="./gallery_detail.html">
								<img src="images/gallery/8.jpg" class="img-responsive" alt=""/>
								<h4>Eodem modo typi, qui nunc nobis videntur parum clari</h4>
							</a>
						</div>
					</div>
				</li>
			</ul>
		</div>

		<!-- Sidebar -->
		<?php
 	include("side.php");
		?>
	
	</div>
	<!-- Footer -->
	<?php
 	include("foter.php");
		?>
</div>
</div>
<div class="clearfix space30"></div>
</body>
</html>
