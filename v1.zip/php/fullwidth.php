<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->
<head>

	<!-- Meta -->
	<meta charset="utf-8">
	<meta name="keywords" content="HTML5 Template" />
	<meta name="description" content="">
	<meta name="author" content="">

    <title>Gazeta - Responsive Magazine Blog Template</title>

	<!-- Mobile Metas -->
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<!-- Favicons -->
	<link rel="shortcut icon" href="img/favicon.ico">

	<!-- Google Fonts & Fontawesome -->
	<link href="http://maxcdn.bootstrapcdn.com/font-awesome/4.2.0/css/font-awesome.min.css" rel="stylesheet" type="text/css">
	<link href='http://fonts.googleapis.com/css?family=Playfair+Display:400,400italic,700,700italic,900,900italic' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Josefin+Sans:400,100,300,300italic,100italic,400italic,600,600italic,700,700italic' rel='stylesheet' type='text/css'>
	<link href='http://fonts.googleapis.com/css?family=Oswald:400,700,300' rel='stylesheet' type='text/css'>

	<!-- CSS -->
    <link rel="stylesheet" href="css/bootstrap.css">
	<link rel="stylesheet" href="js/vendor/slick/slick.css">
    <link rel="stylesheet" href="css/style.css">

    <!-- HTML5 Shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!-- WARNING: Respond.js doesn't work if you view the page via file:// -->
    <!--[if lt IE 9]>
        <script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js"></script>
        <script src="https://oss.maxcdn.com/libs/respond.js/1.4.2/respond.min.js"></script>
    <![endif]-->

	<!-- JS - MEDIAQUERIES -->
	<script src="js/css3-mediaqueries.js"></script>
	
</head>
<body>

<!-- Topbar -->
<div class="top-bar container">
	<div class="row">
		<div class="col-md-6">
			<ul class="tb-left">
				<li class="tbl-date">Today is: <span>Tuesday, November 4, 2014</span></li>
				<li class="tbl-temp"><i class="fa fa-sun-o"></i>32 C</li>
			</ul>
		</div>
		<div class="col-md-6">
			<ul class="tb-right">
				<li class="tbr-social">
					<span>
					<a href="#" class="fa fa-facebook"></a>
					<a href="#" class="fa fa-twitter"></a>
					<a href="#" class="fa fa-google-plus"></a>
					<a href="#" class="fa fa-pinterest"></a>
					<a href="#" class="fa fa-youtube"></a>
					<a href="#" class="fa fa-rss"></a>
					</span>
				</li>
				<li class="tbr-login">
					<a href="./login.php">Login</a>
				</li>
			</ul>
		</div>
	</div>
</div>

<div class="container wrapper">
	<!-- Header -->
	<header>
		<div class="col-md-12">
			<div class="row">

				<!-- Navigation -->
				<div class="col-md-12">
					<div class="menu-trigger"><i class="fa fa-align-justify"></i> Menu</div>
					<nav>
						<ul>
							<li class="active">
								<a href="#" class="sub-nav">Pages</a>
								<ul class="mega-menu">
									<li class="sub-menu">
										<ul>
											<li><a href="./index.html">Index 1</a></li>
											<li><a href="./index_2.html">Index 2</a></li>
											<li><a href="./index_3.html">Index 3</a></li>
											<li><a href="./about.html">About</a></li>
										</ul>
									</li>
									<li class="sub-menu">
										<ul>
											<li><a href="./archives.html">Archives</a></li>
											<li><a href="./category.html">Category</a></li>
											<li><a href="./contributor.html">Contributor</a></li>
										</ul>
									</li>
									<li class="sub-menu">
										<ul>
											<li><a href="./gallery_index.html">Gallery</a></li>
											<li><a href="./gallery_detail.html">Gallery Details</a></li>
											<li><a href="./login.html">Login</a></li>
										</ul>
									</li>
									<li class="sub-menu">
										<ul>
											<li><a href="./search_results.html">Search Results</a></li>
											<li><a href="./single_post.html">Single Post</a></li>
											<li><a href="./contact.html">Contact</a></li>
										</ul>
									</li>
									<li class="sub-menu">
										<ul>
											<li><a href="./video_index.html">Video Gallery</a></li>
											<li><a href="./video_detail.html">Single Video</a></li>
											<li><a href="./fullwidth.html">Full Width</a></li>
										</ul>
									</li>
								</ul>
							</li>
							<li><a href="#">Sport</a></li>
							<li><a href="#">Live News</a></li>
							<li><a href="#">Entertainment</a></li>
							<li><a href="#">Culture</a></li>
							<li><a href="#">Travelling</a></li>
							<li><a href="#">More</a></li>

						</ul>
					</nav>

					<!-- Search -->
					<div class="search">
						<form>
							<input type="search" placeholder="Type to search and hit enter">
						</form>
					</div>
					<span class="search-trigger"><i class="fa fa-search"></i></span>
				</div>
			</div>
		</div>
	</header>

	<div class="header">
		<div class="col-md-12">
			<div class="col-md-12">
				<!-- Logo -->
				<div class="col-md-4 logo">
					<h1><a href="./index.html">BonPom News</a></h1>
				</div>

				<!-- News Ticker -->
				<div class="col-md-8">
					<div class="news-ticker">
						<div id="news-ticker">
							<div class="item">
								<span>Entertainment</span>
								<h4><a href="./single_post.html">Movie : Mother - Real Beauty Comes from the Inside of a Woman</a></h4>
								<p>Posted on : November 4, 2014</p>
							</div>
							<div class="item">
								<span>Sport</span>
								<h4><a href="./single_post.html">Temper Cum Soluta Nobis Eleifend Option Congue Nihil</a></h4>
								<p>Posted on : November 2, 2014</p>
							</div>
							<div class="item">
								<span>Business</span>
								<h4><a href="./single_post.html">Duis autem vel irure dolor in hendrerit in vulputate</a></h4>
								<p>Posted on : November 1, 2014</p>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>

	<!-- Fullwidth Content -->
	<div class="main-content container">
		<div class="col-md-12 blog-single">
			<div class="bs-meta">
				<span class="bs-cat">Uncategorized</span>
				<span class="bs-comments"><a href="#"><i class="fa fa-comments-o"></i> 4 Comments</a> <em></em> <a href="#"><i class="fa fa-heart-o"></i> 23 Likes</a></span>
			</div>
			<h3>Long Traffic Jams Occur in The City Because there is a Demo Rising Oil Prices</h3>
			<div class="row">
				<div class="col-md-2 bs-aside">
					<img src="images/xtra/2.png" alt=""/>
					<h6>John Smith</h6>
					<div class="sep1"></div>
					<div class="space10"></div>
					<div class="rp-date">
						<span>November</span>
						04
						<span><em>/</em> 2014</span>
					</div>
					<div class="space30"></div>
					<div class="sep1"></div>
					<div class="space20"></div>
					<em class="share-count">10K SHARE</em>
					<span class="bsa-social">
					<a href="#"><i class="fa fa-facebook"></i></a>
					<a href="#"><i class="fa fa-twitter"></i></a>
					<a href="#"><i class="fa fa-plus"></i></a>
					</span>
				</div>
				
				<div class="col-md-10">
					<div class="row">
						<div class="col-md-6">
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam el eum iriure dolor in hendrerit in vulputate velit esse molestie consequat; est usus legentis in iis qui facit eorum claritatem. Investigationes <a href="#">demonstraverunt</a> lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.</p>
							<div class="img-w-caption">
								<img src="images/blog/1.jpg" class="img-responsive" alt=""/>
								<span>Example : This is image caption fo sample</span>
							</div>
							<p>Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum. Mirum est notare quam littera</p>
							<p class="quote quote-fullwidth">
								Claritas est etiam process dynamicus, qui sequitur mutationem consue tudium lectorum mirum est notare quam littera 
							</p>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.</p>
						</div>
						
						<div class="col-md-6">
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.</p>
							<h5>Heading Title Font Size</h5>
							<p>Typi non habent claritatem insitam; est usus legentis in iis qui facit eorum claritatem. Investigationes demonstraverunt lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.</p>
							<ul class="list">
								<li>Mirum est notare quam littera gothica</li>
								<li>Anteposuerit litterarum formas humanitatis</li>
								<li>Eodem modo typi, qui nunc nobis videntur parum</li>
								<li>Legentis in iis qui facit eorum claritatem</li>
							</ul>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum.</p>
							<h4>Heading Two : Table Section</h4>
							
							<table class="bs-table">
								<thead>
									<tr>
										<th>Heading One</th>
										<th>Heading Two</th>
										<th>Heading Three</th>
									</tr>
								</thead>
								<tbody>
									<tr>
										<td>Division One</td>
										<td>Division One</td>
										<td>Division One</td>
									</tr>
									<tr>
										<td>Division Two</td>
										<td>Division Two</td>
										<td>Division Two</td>
									</tr>
									<tr>
										<td>Division Three</td>
										<td>Division Three</td>
										<td>Division Three</td>
									</tr>
								</tbody>
							</table>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi.</p>
						</div>
					</div>
					
					<div class="bs-tags">
						<span>Categories : <a href="#">Uncategorized</a></span>
						<span>Tags : <a href="#">Basket,</a> <a href="#">Dunk,</a> <a href="#">Jump</a></span>
					</div>
					
					<div class="bg-share">
						<div class="row">
							<div class="col-md-8">
								<span>Share this post</span>
							</div>
							<div class="col-md-4">
								<a href="#"><i class="fa fa-heart"></i> Like this post</a>
							</div>
						</div>
					</div>
					
					<div class="post-nav">
						<div class="row">
							<div class="col-md-6 pn-prev">
								<a href="#" class="pull-left"><em>&#8592;</em> Previous Post</a>
								<h4><a href="#">Duis Autem vel Eum Iriure Dolor in Hendrerit in Vulputate Velit</a></h4>
							</div>
							<div class="col-md-6 pn-next">
								<a href="#" class="pull-right">Next Post <em>&#8594;</em></a>
								<h4><a href="#">luptatum Zzril Delenit Augue Duis Dolore te Feugait Nulla Facilisi</a></h4>
							</div>
						</div>
					</div>
					
					<div class="author-info">
						<img src="images/xtra/2.png" alt=""/>
						<div class="ai-info">
							<h6>William Doe</h6>
							<p>Claritas est etiam processus dynamicus, qui sequitur mutationem consue tudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus</p>
						</div>
					</div>
				</div>
			</div>
			
			<div class="row">
				<div class="col-md-8 col-md-offset-2">
				
					<!-- Related Post -->
					<div class="related-posts">
						<h5>Related Post</h5>
						<ul>
							<li>
								<div class="col-md-3">
									<div class="rp-date">
										<span>November</span>
										04
										<span><em>/</em> 2014</span>
									</div>
								</div>
								<div class="col-md-9">
									<img src="images/blog/1/1.jpg" class="img-responsive" alt=""/>
									<div class="rp-inner">
										<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
										<a href="#" class="rp-more">Read more  <em>&#8594;</em></a>
									</div>
								</div>
							</li>
							<li>
								<div class="col-md-3">
									<div class="rp-date">
										<span>October</span>
										29
										<span><em>/</em> 2014</span>
									</div>
								</div>
								<div class="col-md-9">
									<img src="images/blog/1/2.jpg" class="img-responsive" alt=""/>
									<div class="rp-inner">
										<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
										<a href="#" class="rp-more">Read more  <em>&#8594;</em></a>
									</div>
								</div>
							</li>
							<li>
								<div class="col-md-3">
									<div class="rp-date">
										<span>October</span>
										23
										<span><em>/</em> 2014</span>
									</div>
								</div>
								<div class="col-md-9">
									<img src="images/blog/1/3.jpg" class="img-responsive" alt=""/>
									<div class="rp-inner">
										<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
										<a href="#" class="rp-more">Read more  <em>&#8594;</em></a>
									</div>
								</div>
							</li>
						</ul>
					</div>
					
					<!-- Comments -->
					<div class="comments-wrap">
						<div id="tabwrap">
							<ul id="tabs">
								<li class="current"><a href="#comments">4 Comments</a></li>
								<li><a href="#lcomment">Leave your comment</a></li>
							</ul>
							<div id="content">
							
								<div id="comments" class="current">
									<ul class="comments">
										<li>
											<div class="c-img"><img src="images/xtra/3.png" alt=""/></div>
											<div class="comment-inner">
												<h6><span>John Smith</span> <a href="#">Reply</a></h6>
												<span class="c-date">20 Hours ago</span>
												<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat</p>
											</div>
										</li>
										<li>
											<div class="c-img"><img src="images/xtra/4.png" alt=""/></div>
											<div class="comment-inner">
												<h6><span>Roman Jackobson</span> <a href="#">Reply</a></h6>
												<span class="c-date">20 Hours ago</span>
												<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat</p>
											</div>
										</li>
										<li class="sub-comment">
											<div class="c-img"><img src="images/xtra/5.png" alt=""/></div>
											<div class="comment-inner">
												<h6><span>Selim Syza</span> <a href="#">Reply</a></h6>
												<span class="c-date">20 Hours ago</span>
												<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat</p>
											</div>
										</li>
										<li>
											<div class="c-img"><img src="images/xtra/6.png" alt=""/></div>
											<div class="comment-inner">
												<h6><span>Halim Mula</span> <a href="#">Reply</a></h6>
												<span class="c-date">20 Hours ago</span>
												<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat</p>
											</div>
										</li>
									</ul>
								</div>
								<div id="lcomment">
									<div class="bs-comment">
										<form class="c-form">
											<p>Your email address will not be published. Required fields are marked <span>*</span></p>
											<label>Name <span>*</span></label>
											<input type="text">
											<label>Email <span>*</span></label>
											<input type="text">
											<label>Website</label>
											<input type="text">									
											<label>Comment</label>
											<textarea></textarea>
											<button type="submit">Post Comment</button>
										</form>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>	

	<!-- Banner Full -->
	<div class="big-banner">
		<a href="#"><img src="images/banner/3.jpg" class="img-responsive" alt=""/></a>
	</div>
	
	
	
	<!-- Footer -->
	<footer class="container">
		<div class="col-md-4 footer-widget footer-logo">
			<h3>BonPon News</h3>
			<br>
			<p>
				<b>Our Office</b><br>
				Street Tapeta, 2nd Floor<br>
				Mahalla e zgjyrave, numer 55518<br>
				Sheher i vogel
			</p>
			<span class="copy">Copyright &copy; 2018 Gazeta. shiwwz <a href="#">PremiumLayers</a></span>
		</div>
		
		<div class="col-md-4 footer-widget p-news">
			<h5>Most Commented</h5>
			<ul>
				<li>
					<img src="images/aside/1.jpg" alt=""/>
					<div class="pn-info">
						<span>Politic</span>
						<h4><a href="./single_post.html">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></h4>
					</div>
				</li>
				<li>
					<img src="images/aside/2.jpg" alt=""/>
					<div class="pn-info">
						<span>Politic</span>
						<h4><a href="./single_post.html">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></h4>
					</div>
				</li>
				<li>
					<img src="images/aside/3.jpg" alt=""/>
					<div class="pn-info">
						<span>Business</span>
						<h4><a href="./single_post.html">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></h4>
					</div>
				</li>
			</ul>
		</div>
		
		<div class="col-md-4 footer-widget f-gallery">
			<h5>Gallery Index</h5>
			<ul>
				<li><a href="#"><img src="images/aside/2/1.jpg" class="img-responsive" alt=""/></a></li>
				<li><a href="#"><img src="images/aside/2/2.jpg" class="img-responsive" alt=""/></a></li>
				<li><a href="#"><img src="images/aside/2/3.jpg" class="img-responsive" alt=""/></a></li>
				<li><a href="#"><img src="images/aside/2/4.jpg" class="img-responsive" alt=""/></a></li>
				<li><a href="#"><img src="images/aside/2/5.jpg" class="img-responsive" alt=""/></a></li>
				<li><a href="#"><img src="images/aside/2/6.jpg" class="img-responsive" alt=""/></a></li>
				<li><a href="#"><img src="images/aside/2/7.jpg" class="img-responsive" alt=""/></a></li>
				<li><a href="#"><img src="images/aside/2/8.jpg" class="img-responsive" alt=""/></a></li>
				<li><a href="#"><img src="images/aside/2/9.jpg" class="img-responsive" alt=""/></a></li>
			</ul>
		</div>
	</footer>
	
	<!-- Footer - Fixed -->
	<div class="footer-fixed">
		<div class="row">
			<div class="col-md-6">
				<ul class="footer-nav">
					<li><a href="#">Home</a></li>
					<li><a href="#">About Us</a></li>
					<li><a href="#">Contact Us</a></li>
					<li><a href="#">Archives</a></li>
				</ul>
			</div>
			<div class="col-md-6">
				<p class="copy1">Copyright &copy; 2018  shiwwez <a href="#" class="fa fa-arrow-up"></a></p>
			</div>
		</div>
	</div>
</div>
</div>

<div class="clearfix space30"></div>

<!-- Javascript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/vendor/slick/slick.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/main.js"></script>

</body>
</html>
