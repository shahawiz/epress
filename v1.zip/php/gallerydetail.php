<!DOCTYPE html>
<head>
    <title>BonPom News</title>
	<script src="js/css3-mediaqueries.js"></script>
	
</head>
<body>
<!-- Topbar -->
<?php
include("topbar.php");
?>

<div class="container wrapper">

<!-- header -->
<?php
include("header.php");
?>
	<!-- Gallery - Single -->
	<div class="main-content container">
		<div class="col-md-8 blog-single blog-single-gal">
			<div class="bs-meta">
				<span class="bs-cat">Gallery page</span>
				<span class="bs-comments"><a href="#"><i class="fa fa-comments-o"></i> 4 Comments</a> <em></em> <a href="#"><i class="fa fa-heart-o"></i> 23 Likes</a></span>
			</div>
			
			<h3>Long Traffic Jams Occur in The City Because there is a Demo Rising Oil Prices</h3>
			<div class="gal-wrap">
				<div id="gal-slider" class="flexslider">
					<ul class="slides">
						<li><img src="images/gallery/1/1.jpg" alt=""/></li>
						<li><img src="images/gallery/1/2.jpg" alt=""/></li>
						<li><img src="images/gallery/1/3.jpg" alt=""/></li>
						<li><img src="images/gallery/1/4.jpg" alt=""/></li>
					</ul>
					<a href="#" class="flex-prev"><i class="fa fa-chevron-left"></i></a>
					<a href="#" class="flex-next"><i class="fa fa-chevron-right"></i></a>
				</div>
				
				<ul class="gal-nav">
					<li>
						<div>
							<img src="images/gallery/1/1-1.jpg" alt=""/>
						</div>
					</li>
					<li>
						<div>
							<img src="images/gallery/1/2-1.jpg" alt=""/>
						</div>
					</li>
					<li>
						<div>
							<img src="images/gallery/1/3-1.jpg" alt=""/>
						</div>
					</li>
					<li>
						<div>
							<img src="images/gallery/1/4-1.jpg" alt=""/>
						</div>
					</li>
				</ul>
			</div>
			
			<div class="row">
				<div class="col-md-3 bs-aside">
					<img src="images/xtra/2.png" alt=""/>
					<h6>John Smith</h6>
					<div class="sep1"></div>
					<div class="space10"></div>
					<div class="rp-date">
						<span>November</span>
						04
						<span><em>/</em> 2014</span>
					</div>
					<div class="space30"></div>
					<div class="sep1"></div>
					<div class="space20"></div>
					<em class="share-count">10K SHARE</em>
					<span class="bsa-social">
					<a href="#"><i class="fa fa-facebook"></i></a>
					<a href="#"><i class="fa fa-twitter"></i></a>
					<a href="#"><i class="fa fa-plus"></i></a>
					</span>
				</div>
				
				<div class="col-md-9">
					<p class="space20">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil imperdiet doming id quod mazim placerat facer possim assum. Typi non habent claritatem insitam el eum iriure dolor in hendrerit in vulputate velit esse molestie consequat; est usus legentis in iis qui facit eorum claritatem. Investigationes <a href="#">demonstraverunt</a> lectores legere me lius quod ii legunt saepius. Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.</p>
					<p>Claritas est etiam processus dynamicus, qui sequitur mutationem consuetudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum. quam nunc putamus parum claram, anteposuerit litterarum formas humanitatis per seacula quarta decima et quinta decima. Eodem modo typi, qui nunc nobis videntur parum clari, fiant sollemnes in futurum.</p>
					<div class="bs-tags">
						<span>Categories : <a href="#">Uncategorized</a></span>
						<span>Tags : <a href="#">Basket,</a> <a href="#">Dunk,</a> <a href="#">Jump</a></span>
					</div>
					
					<div class="bg-share">
						<div class="row">
							<div class="col-md-8">
								<span>Share this post</span>
							</div>
							<div class="col-md-4">
								<a href="#"><i class="fa fa-heart"></i> Like this post</a>
							</div>
						</div>
					</div>
					
					<div class="author-info">
						<img src="images/xtra/2.png" alt=""/>
						<div class="ai-info">
							<h6>John Smith</h6>
							<p>Claritas est etiam processus dynamicus, qui sequitur mutationem consue tudium lectorum. Mirum est notare quam littera gothica, quam nunc putamus</p>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Related Posts -->
			<div class="related-posts-video">
				<h5>Other Galleries</h5>
				<ul class="i-gallery">
					<li>
						<div class="ig-main">
							<div class="ig-wrap">
								<a href="#">
									<img src="images/gallery/3.jpg" class="img-responsive" alt=""/>
									<h4>Eodem modo typi, qui nunc nobis videntur parum clari</h4>
								</a>
							</div>
						</div>
					</li>
					<li>
						<div class="ig-main">
							<div class="ig-wrap">
								<a href="#">
									<img src="images/gallery/4.jpg" class="img-responsive" alt=""/>
									<h4>Eodem modo typi, qui nunc nobis videntur parum clari</h4>
								</a>
							</div>
						</div>
					</li>
				</ul>
			</div>
			
			<!-- Comments -->
			<div class="comments-wrap">
				<div id="tabwrap">
					<ul id="tabs">
						<li class="current"><a href="#comments">4 Comments</a></li>
						<li><a href="#lcomment">Leave your comment</a></li>
					</ul>
					<div id="content">
						<div id="comments" class="current">
							<ul class="comments">
								<li>
									<div class="c-img"><img src="images/xtra/3.png" alt=""/></div>
									<div class="comment-inner">
										<h6><span>Bob Marchetti</span> <a href="#">Reply</a></h6>
										<span class="c-date">20 Hours ago</span>
										<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat</p>
									</div>
								</li>
								<li>
									<div class="c-img"><img src="images/xtra/4.png" alt=""/></div>
									<div class="comment-inner">
										<h6><span>Michael Kosim</span> <a href="#">Reply</a></h6>
										<span class="c-date">20 Hours ago</span>
										<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat</p>
									</div>
								</li>
								<li class="sub-comment">
									<div class="c-img"><img src="images/xtra/5.png" alt=""/></div>
									<div class="comment-inner">
										<h6><span>Michael Kosim</span> <a href="#">Reply</a></h6>
										<span class="c-date">20 Hours ago</span>
										<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat</p>
									</div>
								</li>
								<li>
									<div class="c-img"><img src="images/xtra/6.png" alt=""/></div>
									<div class="comment-inner">
										<h6><span>Jony Kurniawan</span> <a href="#">Reply</a></h6>
										<span class="c-date">20 Hours ago</span>
										<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat</p>
									</div>
								</li>
							</ul>
						</div>
						<div id="lcomment">
							<div class="bs-comment">
								<form class="c-form">
									<p>Your email address will not be published. Required fields are marked <span>*</span></p>
									<label>Name <span>*</span></label>
									<input type="text">
									<label>Email <span>*</span></label>
									<input type="text">
									<label>Website</label>
									<input type="text">									
									<label>Comment</label>
									<textarea></textarea>
									<button type="submit">Post Comment</button>
								</form>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>



	<!-- side bar -->
	<?php
 	include("side.php");
		?>
	</div>


	<!-- Footer -->
	<?php
 	include("foter.php");
		?>
</div>
</div>
</div>

<div class="clearfix space30"></div>

<!-- Javascript -->
<script src="js/jquery.min.js"></script>
<script src="js/vendor/flex-slider/jquery.flexslider.js"></script>
<script src="js/vendor/flex-slider/main.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/vendor/slick/slick.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/main.js"></script>

</body>
</html>
