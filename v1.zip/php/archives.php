<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->
<head>
	
</head>
<body>
<!-- Topbar -->
<?php
include("topbar.php");
?>
<div class="container wrapper">
		<!-- Header -->
		<?php
 	include("header.php");
		?>
	<!-- Archives Content -->
	<div class="main-content container">
		<div class="col-md-8 blog-single">
			<div class="bs-meta">
				<span class="bs-cat">Archives</span>
			</div>
			<div class="space30"></div>
			<div class="archives-content">
				<h3>The People Behind Success of Gazeta</h3>			
				<!-- Archives -->
				<div class="related-posts related-posts-cat">
					<ul>
						<li>
							<div class="col-md-3">
								<div class="rp-date">
									<span>November</span>
									04
									<span><em>/</em> 2014</span>
								</div>
							</div>
							<div class="col-md-9">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
							</div>
						</li>
						
						<li>
							<div class="col-md-3">
								<div class="rp-date">
									<span>October</span>
									29
									<span><em>/</em> 2014</span>
								</div>
							</div>
							<div class="col-md-9">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
							</div>
						</li>
						
						<li>
							<div class="col-md-3">
								<div class="rp-date">
									<span>October</span>
									23
									<span><em>/</em> 2014</span>
								</div>
							</div>
							<div class="col-md-9">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
							</div>
						</li>
						

						
						<li>
							<div class="col-md-3">
								<div class="rp-date">
									<span>September</span>
									30
									<span><em>/</em> 2014</span>
								</div>
							</div>
							<div class="col-md-9">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
							</div>
						</li>
						
						<li>
							<div class="col-md-3">
								<div class="rp-date">
									<span>September</span>
									25
									<span><em>/</em> 2014</span>
								</div>
							</div>
							<div class="col-md-9">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
							</div>
						</li>
						
						<li>
							<div class="col-md-3">
								<div class="rp-date">
									<span>September</span>
									12
									<span><em>/</em> 2014</span>
								</div>
							</div>
							<div class="col-md-9">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
							</div>
						</li>
						
						<li>
							<div class="col-md-3">
								<div class="rp-date">
									<span>September</span>
									06
									<span><em>/</em> 2014</span>
								</div>
							</div>
							<div class="col-md-9">
								<span class="rp-cat">Uncategorized</span>
								<h4><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h4>
							</div>
						</li>
					</ul>
				</div>
			</div>
			
			<!-- Archives Filter -->
			<div class="row archives-filter">
				<div class="col-md-6">
					<h5>Archive By Month</h5>
					<span><a href="#">August 2014</a></span>
					<span><a href="#">February 2013</a></span>
					<span><a href="#">January 2013</a></span>
					<span><a href="#">September 2012</a></span>
					<span><a href="#">August 2012</a></span>
					<span><a href="#">May 2012</a></span>
					<span><a href="#">March 2012</a></span>
				</div>
				
				<div class="col-md-6">
					<h5>Archive By Categories</h5>
					<span><a href="#">Business</a></span>
					<span><a href="#">Entertainment</a></span>
					<span><a href="#">Fashion</a></span>
					<span><a href="#">Food</a></span>
					<span><a href="#">Travelling</a></span>
					<span><a href="#">Sports</a></span>
					<span><a href="#">Technology</a></span>
					<span><a href="#">Uncategorized</a></span>
				</div>
			</div>
		</div>
	
	<!-- side bar -->
		<?php
 	include("side.php");
		?>
	</div>


	<!-- Footer -->
	<?php
 	include("foter.php");
		?>
</div>

<div class="clearfix space30"></div>


</body>
</html>
