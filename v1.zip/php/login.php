<?php include('server.php') ?>

<!DOCTYPE html>

<head>

</head>
<body>

<!-- Topbar -->
<?php
include("topbar.php");
?>
<div class="container wrapper">

	<!-- Header -->
	<?php
 	include("header.php");
		?>
		


	<!-- Main Content -->
	<div class="main-content container">
		<div class="col-md-12 blog-single">
			<div class="bs-meta">
				<span class="bs-cat">Login or Register</span>
			</div>
			<div class="space30"></div>
			
			<div class="logreg-content">
				<div class="row">
				<?php include('errors.php'); ?>
					<!-- Login -->
					<form method="post">
					<div class="col-md-6">
						<div class="login-content">
							<h6>Login</h6>
							<form>

							<label>Username</label>
  							<input type="text" name="username" >

							  <label>Password</label>
  							<input type="password" name="password">
							  <button type="submit" class="btn" name="login_user">Login</button>
								<input type="checkbox">Remember me
							</form>
						</div>
					</div>
					
					<!-- Register -->
					<div class="col-md-6">
						<div class="register-content">
							<h6>Register</h6>
							<form method="post">

								<label>Username</label>
  							  	<input type="text" name="username" value="<?php echo $username; ?>">
									<label>Email</label>
  	  								<input type="email" name="email" value="<?php echo $email; ?>">
								<label>Password</label>
  	  							<input type="password" name="password_1">
								<label>Confirm password</label>
  	 							 <input type="password" name="password_2">	
								<button type="submit" class="btn" name="reg_user">Register</button>
								<input type="checkbox">I have read the terms & conditions
							</form>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Footer -->
	<?php
 	include("foter.php");
		?>
</div>
</div>
<div class="clearfix space30"></div>
</body>
</html>
