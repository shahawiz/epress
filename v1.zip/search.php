<!DOCTYPE html>
<!--[if IE 8]>			<html class="ie ie8"> <![endif]-->
<!--[if IE 9]>			<html class="ie ie9"> <![endif]-->
<!--[if gt IE 9]><!-->	<html> <!--<![endif]-->
<head>
    <title>BonPom News</title>
</head>
<body>


<!-- Topbar -->
<?php
include("topbar.php");
?>

<div class="container wrapper">
	<!-- Header -->
<!-- Topbar -->
<?php
include("header.php");
?>

	<!-- Main Content -->
	<div class="main-content container">
		<div class="col-md-8 blog-single">
			<div class="bs-meta">
				<span class="bs-cat">Search Result</span>
			</div>
			
			<div class="space30"></div>
			<div class="search-results row">
				<div class="col-md-12">
					<h3>Search result for : <span>lorem ipsum</span></h3>
				</div>
				
				<div class="col-md-12">
					<div class="fn2-inner">
						<div class="fn2-thumb">
							<img src="images/xtra/3.jpg" class="img-responsive" alt=""/>
						</div>
						<div class="fn2-info">
							<div class="fn2-meta">Technology <span>3 <i class="fa fa-comments"></i></span></div>
							<h4><a href="./single_post.html">Duis autem vel irure dolor in hendrerit in vulputate</a></h4>
							<em>Posted on November 02, 2014</em>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. ex ea commodo consequat ...</p>
						</div>
					</div>
				</div>
				
				<div class="col-md-12">
					<div class="fn2-inner fn2-inner-sub">
						<div class="fn2-info">
							<div class="fn2-meta">Technology</div>
							<h4><a href="./single_post.html">Duis autem vel irure dolor in hendrerit in vulputate</a></h4>
							<em>Posted on November 02, 2014</em>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. ex ea commodo consequat ...</p>
						</div>
					</div>
				</div>
				
				<div class="col-md-12">
					<div class="fn2-inner fn2-inner-sub">
						<div class="fn2-info">
							<div class="fn2-meta">Technology</div>
							<h4><a href="./single_post.html">Duis autem vel irure dolor in hendrerit in vulputate</a></h4>
							<em>Posted on November 02, 2014</em>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. ex ea commodo consequat ...</p>
						</div>
					</div>
				</div>
				
				<div class="col-md-12">
					<div class="fn2-inner fn2-inner-sub">
						<div class="fn2-info">
							<div class="fn2-meta">Technology</div>
							<h4><a href="./single_post.html">Duis autem vel irure dolor in hendrerit in vulputate</a></h4>
							<em>Posted on November 02, 2014</em>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. ex ea commodo consequat ...</p>
						</div>
					</div>
				</div>
				
				<div class="col-md-12">
					<div class="fn2-inner fn2-inner-sub">
						<div class="fn2-info">
							<div class="fn2-meta">Technology</div>
							<h4><a href="./single_post.html">Duis autem vel irure dolor in hendrerit in vulputate</a></h4>
							<em>Posted on November 02, 2014</em>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. ex ea commodo consequat ...</p>
						</div>
					</div>
				</div>
				
				<div class="col-md-12">
					<div class="fn2-inner fn2-inner-sub">
						<div class="fn2-info">
							<div class="fn2-meta">Technology</div>
							<h4><a href="./single_post.html">Duis autem vel irure dolor in hendrerit in vulputate</a></h4>
							<em>Posted on November 02, 2014</em>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. ex ea commodo consequat ...</p>
						</div>
					</div>
				</div>
				
				<div class="col-md-12">
					<div class="fn2-inner fn2-inner-sub">
						<div class="fn2-info">
							<div class="fn2-meta">Technology</div>
							<h4><a href="./single_post.html">Duis autem vel irure dolor in hendrerit in vulputate</a></h4>
							<em>Posted on November 02, 2014</em>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. ex ea commodo consequat ...</p>
						</div>
					</div>
				</div>
				
				<div class="col-md-12">
					<div class="fn2-inner fn2-inner-sub">
						<div class="fn2-info">
							<div class="fn2-meta">Technology</div>
							<h4><a href="./single_post.html">Duis autem vel irure dolor in hendrerit in vulputate</a></h4>
							<em>Posted on November 02, 2014</em>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. ex ea commodo consequat ...</p>
						</div>
					</div>
				</div>
				
				<div class="col-md-12">
					<div class="fn2-inner fn2-inner-sub">
						<div class="fn2-info">
							<div class="fn2-meta">Technology</div>
							<h4><a href="./single_post.html">Duis autem vel irure dolor in hendrerit in vulputate</a></h4>
							<em>Posted on November 02, 2014</em>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. ex ea commodo consequat ...</p>
						</div>
					</div>
				</div>
				
				<div class="col-md-12">
					<div class="fn2-inner fn2-inner-sub">
						<div class="fn2-info">
							<div class="fn2-meta">Technology</div>
							<h4><a href="./single_post.html">Duis autem vel irure dolor in hendrerit in vulputate</a></h4>
							<em>Posted on November 02, 2014</em>
							<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. ex ea commodo consequat ...</p>
						</div>
					</div>
				</div>
			</div>
		</div>

		<!-- Sidebar -->
	<!-- Topbar -->
<?php
include("side.php");
?>
	</div>


	
	<!-- Footer -->

<?php
include("foter.php");
?>
</div>
</div>

<div class="clearfix space30"></div>

<!-- Javascript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/vendor/slick/slick.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/main.js"></script>

</body>
</html>
