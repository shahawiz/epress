<?php 
  session_start(); 

  if (!isset($_SESSION['username'])) {
  	$_SESSION['msg'] = "You must log in first";
  	header('location: login.php');
  }
  if (isset($_GET['logout'])) {
  	session_destroy();
  	unset($_SESSION['username']);
  	header("location: login.php");
  }
?>
<!DOCTYPE html>
<head>
    <title>Gazeta - Responsive Magazine Blog Template</title>
	<script src="js/css3-mediaqueries.js"></script>

</head>
<body>

<!-- Topbar -->
<?php
include("topbar.php");
?>

<div class="container wrapper">

	<!-- Header -->

	<?php
 	include("header.php");
		?>
	

	<div class="content">
  	<!-- notification message -->
  	<?php if (isset($_SESSION['success'])) : ?>
      <div class="error success" >
      	<h3>
          <?php 
          	echo $_SESSION['success']; 
          	unset($_SESSION['success']);
          ?>
      	</h3>
      </div>
  	<?php endif ?>

    <!-- logged in user information -->
	<!-- Main Content -->
	<div class="main-content container">
		<div class="col-md-8 block-1">
			<div class="row">
				<div class="col-md-3 b1-aside">
					<h5><span>Latest News</span></h5>
					<div class="bla-content">
						<div class="thumb">
							<img src="images/xtra/1.jpg" class="img-responsive" alt=""/>
							<span class="thumb-cat">Technology</span>
						</div>
						<p>Posted on November 02, 2014</p>
						<h4><a href="./index.php">Tempor Cum Soluta Nobis Eleifend Option Congue Nihil</a></h4>
						<div class="sep"></div>
						<span class="cat-default">Sport</span>
						<p>Posted on November 02, 2014</p>
						<h4><a href="./index.php">Tempor Cum Soluta Nobis Eleifend Option Congue Nihil</a></h4>
						<div class="sep"></div>
						<span class="cat-default">Business</span>
						<p>Posted on November 02, 2014</p>
						<h4><a href="./index.php">Tempor Cum Soluta Nobis Eleifend Option Congue Nihil</a></h4>
						<div class="sep"></div>
						<span class="cat-default">Entertainment</span>
						<p>Posted on November 02, 2014</p>
						<h4><a href="./index.php">Tempor Cum Soluta Nobis Eleifend Option Congue Nihil</a></h4>
						<div class="sep"></div>
						<span class="cat-default">Entertainment</span>
						<p>Posted on November 02, 2014</p>
						<h4><a href="./index.php">Tempor Cum Soluta Nobis Eleifend Option Congue Nihil</a></h4>
						<div class="sep"></div>
						<a href="#" class="btn1">View All Posts</a>
					</div>
					<div class="bla-content banner">
						<img src="images/banner/1.jpg" class="img-responsive" alt=""/>
					</div>
				</div>
				
				<div class="col-md-9 block-right">
					<div class="bl-featured-big">
						<div class="bl-meta">
							<span><i class="fa fa-comments-o"></i> 4 Comments</span><br>
							<span><i class="fa fa-heart-o"></i> 23 Likes</span>
						</div>
						<img src="images/xtra/2.jpg" class="img-responsive" alt=""/>
						<div class="bl-info">
							<span>Entertainment</span>
							<h3><a href="./single_post.html">Claritas Est Etiam Processus Dynamicus, Qui Sequitur Mutationem </a></h3>
							<a class="rmore" href="#">Continue Reading <i class="fa fa-arrow-right"></i></a>
						</div>
					</div>
					
					<!-- Featured News -->
					<div class="featured-news">
						<h5><span>Featured News</span></h5>
						<div class="row">
							<div class="col-md-6">
								<div class="fn-inner">
									<div class="fn-thumb">
										<img src="images/xtra/3.jpg" class="img-responsive" alt=""/>
										<div class="fn-meta">Technology <span>3 <i class="fa fa-comments"></i></span></div>
									</div>
									<h4><a href="./single_post.html">Duis autem vel irure dolor in hendrerit in vulputate</a></h4>
									<em>Posted on November 02, 2014</em>
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. ex ea commodo consequat ...</p>
								</div>
								<div class="fn-inner">
									<div class="fn-thumb">
										<img src="images/xtra/4.jpg" class="img-responsive" alt=""/>
										<div class="fn-meta">Sport <span>3 <i class="fa fa-comments"></i></span></div>
									</div>
									<h4><a href="./single_post.html">Duis autem vel irure dolor in hendrerit in vulputate</a></h4>
									<em>Posted on November 02, 2014</em>
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. ex ea commodo consequat ...</p>
								</div>
							</div>
							
							<div class="col-md-6">
								<div class="fn-inner">
									<div class="fn-thumb">
										<img src="images/xtra/5.jpg" class="img-responsive" alt=""/>
										<div class="fn-meta">Culture <span>3 <i class="fa fa-comments"></i></span></div>
									</div>
									<h4><a href="./single_post.html">Duis autem vel irure dolor in hendrerit in vulputate</a></h4>
									<em>Posted on November 02, 2014</em>
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. ex ea commodo consequat ...</p>
								</div>
								<div class="fn-inner">
									<div class="fn-thumb">
										<img src="images/xtra/6.jpg" class="img-responsive" alt=""/>
										<div class="fn-meta">Travelling <span>3 <i class="fa fa-comments"></i></span></div>
									</div>
									<h4><a href="./single_post.html">Duis autem vel irure dolor in hendrerit in vulputate</a></h4>
									<em>Posted on November 02, 2014</em>
									<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. ex ea commodo consequat ...</p>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<!-- Category Blocks -->
			<div class="row">
				<div class="col-md-12">
					<div class="cat-blocks">
						<h4><span>Technology</span></h4>
						<div class="row">
							<div class="col-md-6">
								<div class="cb-big">
									<div class="bl-meta">
										<span><i class="fa fa-comments-o"></i> 4 Comments</span><br>
										<span><i class="fa fa-heart-o"></i> 23 Likes</span>
									</div>
									<img src="images/xtra/7.jpg" class="img-responsive" alt=""/>
									<div class="bl-info">
										<h3><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h3>
										<p>Posted on November 02, 2014</p>
									</div>
								</div>
							</div>
							
							<div class="col-md-6 cb-info">
								<span class="cat">Technology</span>									
								<h5><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h5>
								<span class="date">Posted on November 02, 2014</span>
								<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt laoreet doloremagna aliquam erat volutpat. ex ea commodo</p>
								<ul>
									<li><a href="./single_post.html">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></li>
									<li><a href="./single_post.html">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></li>
									<li><a href="./single_post.html">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></li>
								</ul>
							</div>
						</div>
						<div class="space40"></div>
					</div>
					
					<div class="cat-blocks">
						<h4><span>Business</span></h4>
						<div class="row">
							<div class="col-md-6">
								<div class="cb-big">
									<div class="bl-meta">
										<span><i class="fa fa-comments-o"></i> 4 Comments</span><br>
										<span><i class="fa fa-heart-o"></i> 23 Likes</span>
									</div>
									<img src="images/xtra/8.jpg" class="img-responsive" alt=""/>
									<div class="bl-info">
										<h3><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h3>
										<p>Posted on November 02, 2014</p>
									</div>
								</div>
							</div>
							
							<div class="col-md-6 cb-info">
								<span class="cat">Business</span>									
								<h5><a href="./index.php">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h5>
								<span class="date">Posted on November 02, 2014</span>
								<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt laoreet doloremagna aliquam erat volutpat. ex ea commodo</p>
								<ul>
									<li><a href="./index.php">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></li>
									<li><a href="./index.php">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></li>
									<li><a href="./index.php">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></li>
								</ul>
							</div>
						</div>
						<div class="space40"></div>
					</div>
					
					<div class="cat-blocks">
						<h4><span>Entertainment</span></h4>
						<div class="row">
							<div class="col-md-6">
								<div class="cb-big">
									<div class="bl-meta">
										<span><i class="fa fa-comments-o"></i> 4 Comments</span><br>
										<span><i class="fa fa-heart-o"></i> 23 Likes</span>
									</div>
									<img src="images/xtra/9.jpg" class="img-responsive" alt=""/>
									<div class="bl-info">
										<h3><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h3>
										<p>Posted on November 02, 2014</p>
									</div>
								</div>
							</div>
							
							<div class="col-md-6 cb-info">
								<span class="cat">Entertainment</span>									
								<h5><a href="./single_post.html">Eodem Modo Typi, Qui Nunc Nobis Videntur Parum Clari</a></h5>
								<span class="date">Posted on November 02, 2014</span>
								<p>Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt laoreet doloremagna aliquam erat volutpat. ex ea commodo</p>
								<ul>
									<li><a href="./single_post.html">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></li>
									<li><a href="./single_post.html">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></li>
									<li><a href="./single_post.html">Lorem Ipsum Dolor Sit Amet, Consetetuer Adipiscing Elit</a></li>
								</ul>
							</div>
						</div>
						<div class="space40"></div>
					</div>
					
					<div class="cat-blocks">
						<h4><span>Your Opinion</span></h4>
						<div class="row">
							<div class="col-md-6">
								<div class="op-twitter">
									<div class="opt-inner">
										<p>Check out 'Gazeta - Magazine HTML Template ' on <a href="#">@EnvatoMarket #themeforest<br> http://themeforest.net/item/gazeta-magazine-html-template--</a></p>
										<em>3 Hours . <a href="#">Reply</a></em>
									</div>
									<span class="ico"><i class="fa fa-twitter"></i></span>	
								</div>
							</div>
							
							<div class="col-md-6">
								<div class="op-info">
									<div class="opi-inner">
										<em>John Smith <span>- Internet Marketer</span></em>
										<p>Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros</p>
									</div>
									<span class="ico"><img src="images/xtra/1.png" alt=""/></span>	
								</div>
							</div>
						</div>
						<div class="space40"></div>
					</div>
				</div>
			</div>
		</div>
	
		<!-- Sidebar -->
			<?php
 	include("side.php");
		?>
	
	</div>
	<!-- Footer -->
	<?php
 	include("foter.php");
		?>
	
</div>
</div>

<div class="clearfix space30"></div>

<!-- Javascript -->
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/vendor/slick/slick.js"></script>
<script src="js/jquery.nicescroll.js"></script>
<script src="js/main.js"></script>

</body>
</html>
